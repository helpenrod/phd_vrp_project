
from dataclasses import dataclass
from typing import List, Tuple
from .registry import register_constraint

Route = List[int]   # sequence of customer indices; depot = 0 (implicit)
Solution = List[Route]

@dataclass
class InstanceData:
    demand: List[float]
    capacity: float
    service: List[float]
    tw: List[Tuple[float, float]]            # (ready, due) for depot+customers (index 0 = depot)
    travel: List[List[float]]                # distance/time matrix including depot 0

@register_constraint("capacity")
class CapacityConstraint:
    """Simple capacity feasibility. Replace with your optimized CVRP check if desired."""
    def __init__(self, inst: InstanceData):
        self.inst = inst

    def route_feasible(self, route: Route) -> bool:
        load = 0.0
        for c in route:
            load += self.inst.demand[c]
            if load > self.inst.capacity + 1e-9:
                return False
        return True

@register_constraint("time_windows")
class TimeWindowConstraint:
    """TW feasibility (no capacity). Depot index 0 is implicit at start/end."""
    def __init__(self, inst: InstanceData):
        self.inst = inst

    def route_feasible(self, route: Route) -> bool:
        t = 0.0
        prev = 0  # depot
        for c in route:
            t += self.inst.travel[prev][c]
            ready, due = self.inst.tw[c]
            if t < ready:
                t = ready
            if t > due + 1e-9:
                return False
            t += self.inst.service[c]
            prev = c
        # return to depot
        t += self.inst.travel[prev][0]
        ready0, due0 = self.inst.tw[0]
        if t < ready0:
            t = ready0
        return t <= due0 + 1e-9

class CompositeConstraint:
    """Logical AND of multiple constraints."""
    def __init__(self, constraints):
        self.constraints = constraints

    def route_feasible(self, route: Route) -> bool:
        return all(c.route_feasible(route) for c in self.constraints)

    def solution_feasible(self, sol: Solution) -> bool:
        return all(self.route_feasible(r) for r in sol)
