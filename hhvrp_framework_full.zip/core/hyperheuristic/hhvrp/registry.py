
from typing import Callable, Dict, Type

_CONSTRAINTS: Dict[str, Type] = {}
_OPERATORS: Dict[str, Callable] = {}
_TEMPLATES: Dict[str, Callable] = {}

def register_constraint(name: str):
    def deco(cls: Type):
        _CONSTRAINTS[name] = cls
        return cls
    return deco

def register_operator(name: str):
    def deco(fn: Callable):
        _OPERATORS[name] = fn
        return fn
    return deco

def register_template(name: str):
    def deco(builder: Callable):
        _TEMPLATES[name] = builder
        return builder
    return deco

def get_constraint(name: str):
    return _CONSTRAINTS[name]

def get_operator(name: str):
    return _OPERATORS[name]

def get_template(name: str):
    return _TEMPLATES[name]

def list_all():
    return {
        "constraints": list(_CONSTRAINTS.keys()),
        "operators": list(_OPERATORS.keys()),
        "templates": list(_TEMPLATES.keys()),
    }
