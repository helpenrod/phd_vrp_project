
"""Bridge that reads existing experiment config.yaml files to auto-register
operators and constraints without writing new manifests.
Adjust LOOKUP tables to your actual operator names.
"""
import yaml
from typing import Dict, List, Tuple
from importlib import import_module
from .registry import register_operator, register_constraint

# Default mapping: map common operator names to hhvrp's built-ins.
# If your configs list other names, extend these tables or point to your experiment modules.
LOOKUP: Dict[str, Dict[str, Tuple[str, str]]] = {
    "alg1_cvrp": {
        "relocate": ("core.hyperheuristic.hhvrp.operators", "op_relocate"),
        "swap": ("core.hyperheuristic.hhvrp.operators", "op_swap"),
        "two_opt_intra": ("core.hyperheuristic.hhvrp.operators", "op_two_opt_intra"),
        "2opt": ("core.hyperheuristic.hhvrp.operators", "op_two_opt_intra"),
    },
    "alg2_vrptw": {
        "relocate": ("core.hyperheuristic.hhvrp.operators", "op_relocate"),
        "swap": ("core.hyperheuristic.hhvrp.operators", "op_swap"),
        "two_opt_intra": ("core.hyperheuristic.hhvrp.operators", "op_two_opt_intra"),
        "2opt": ("core.hyperheuristic.hhvrp.operators", "op_two_opt_intra"),
        "insert_best_feasible_tw": ("core.hyperheuristic.hhvrp.operators", "insert_best_feasible_tw"),
    },
}

CONSTRAINTS_LOOKUP: Dict[str, Dict[str, Tuple[str, str]]] = {
    "alg1_cvrp": {
        "capacity": ("core.hyperheuristic.hhvrp.constraints", "CapacityConstraint"),
    },
    "alg2_vrptw": {
        "time_windows": ("core.hyperheuristic.hhvrp.constraints", "TimeWindowConstraint"),
    },
}

def _ensure_registered(module_path: str, symbol: str, is_constraint=False, public_name=None):
    mod = import_module(module_path)
    obj = getattr(mod, symbol)
    if is_constraint:
        register_constraint(public_name or symbol)(obj)
    else:
        register_operator(public_name or symbol)(obj)

def _extract_ops_from_cfg(cfg: dict) -> List[str]:
    """Extract operator names from GA-style config structure.
    Looks under parameters.operators.{mutation,local_search,crossover}.
    Returns a flat list of lowercase operator names.
    """
    ops = []
    params = cfg.get("parameters", {})
    o = params.get("operators", {})
    for key in ("mutation", "local_search"):
        seq = o.get(key, []) or []
        for name in seq:
            ops.append(str(name).lower())
    xover = o.get("crossover")
    if xover:
        ops.append(str(xover).lower())
    # dedupe preserving order
    seen = set()
    out = []
    for x in ops:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out

def load_experiment_cfg(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)

def register_from_experiment_cfg(pkg_name: str, cfg_path: str):
    cfg = load_experiment_cfg(cfg_path)
    # Register constraints for this package
    for cname, (mod, sym) in (CONSTRAINTS_LOOKUP.get(pkg_name, {}) or {}).items():
        _ensure_registered(mod, sym, is_constraint=True, public_name=cname)
    # Register operators present in the config
    in_cfg = _extract_ops_from_cfg(cfg)
    mapping = LOOKUP.get(pkg_name, {})
    for name in in_cfg:
        if name in mapping:
            mod, sym = mapping[name]
            _ensure_registered(mod, sym, is_constraint=False, public_name=name)
    return cfg, in_cfg

def auto_wire_from_configs(req: List[Tuple[str, str]],
                           extra_ops: List[str] = None,
                           force_constraints: List[str] = None):
    """req: list of (package_name, config_yaml_path)
    Returns a spec dict ready to feed to hhvrp.builder.build_from_yaml.
    """
    operators = []
    constraints = []
    instance = None
    for pkg, cfg_path in req:
        cfg, ops_here = register_from_experiment_cfg(pkg, cfg_path)
        operators.extend(ops_here)
        # prefer the last instance (e.g., TW config, which is richer)
        inst_candidate = cfg.get("instance")
        if inst_candidate:
            instance = inst_candidate
        constraints.extend(list((CONSTRAINTS_LOOKUP.get(pkg, {}) or {}).keys()))
    if extra_ops:
        operators.extend(extra_ops)
    if force_constraints:
        constraints.extend(force_constraints)
    # unique
    def _uniq(x):
        seen = set(); out = []
        for v in x:
            if v not in seen:
                out.append(v); seen.add(v)
        return out
    spec = {
        "seed": 123,
        "instance": instance or {
            "demand": [0],
            "capacity": 0,
            "service": [0],
            "tw": [[0, 1e9]],
            "travel": [[0]],
        },
        "constraints": _uniq(constraints) or ["capacity", "time_windows"],
        "operators": _uniq(operators) or ["relocate", "swap", "two_opt_intra"],
        "template": {"name": "ils_first_improve"}
    }
    return spec
