
    import yaml
    from typing import Dict, List, Tuple
    from .constraints import CompositeConstraint, InstanceData
    from .registry import get_constraint, get_operator, get_template
    from .discovery import load_plugin_manifests

    # Build a solver from a YAML spec, optionally loading plugin manifests from experiments/*
    # YAML keys used:
    #   plugin_manifests: ["experiments.alg1_cvrp/manifest.yaml", "experiments.alg2_vrptw/manifest.yaml"]
    #   instance: {...}
    #   constraints: ["capacity", "time_windows"]
    #   operators: ["relocate", "swap", ...]
    #   template: { name: "ils_first_improve" }
    #   emit: { path: "experiments/alg3_vrptwc/generated_solver.py" }  # optional

    def build_from_yaml(yaml_text: str):
        cfg = yaml.safe_load(yaml_text)

        # 0) Load plugin manifests so their functions/classes get registered by name
        load_plugin_manifests(cfg.get("plugin_manifests", []))

        # 1) Instance wrapper (you supply the arrays)
        inst = InstanceData(**cfg["instance"])  # demand, capacity, service, tw, travel

        # 2) Constraints
        cons = []
        for cname in cfg["constraints"]:
            cons.append(get_constraint(cname)(inst))
        checker = CompositeConstraint(cons)

        # 3) Operators
        ops = [get_operator(name) for name in cfg["operators"]]

        # 4) Template
        template_name = cfg["template"]["name"]
        template = get_template(template_name)
        solver = template(ops)

        return inst, checker, solver, cfg

    def emit_standalone_solver(path: str, cfg: Dict[str, any]):
        """Writes a small self-contained solver file that imports from hhvrp registry
        relying on manifests listed in cfg["plugin_manifests"]."""
        yaml_text = yaml.safe_dump(cfg)
        code = f"""
# Auto-generated solver (VRPTW + capacity) — DO NOT EDIT BY HAND
from core.hyperheuristic.hhvrp.builder import build_from_yaml

CONFIG = r"""\n{yaml_text}\n"""

if __name__ == "__main__":
    inst, checker, solve, cfg = build_from_yaml(CONFIG)
    customers = list(range(1, len(inst.demand)))
    init = [customers]
    sol, cost = solve(inst, init, checker, rng_seed=cfg.get("seed", 0))
    print("cost=", cost)
    print("solution=", sol)
""".lstrip()
        with open(path, "w") as f:
            f.write(code)
