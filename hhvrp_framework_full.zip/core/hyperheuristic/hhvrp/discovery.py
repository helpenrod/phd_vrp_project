
import importlib
import os
import yaml
from .registry import register_constraint, register_operator, register_template

# Manifest schema (YAML) expected inside each experiment package:
# name: alg1_cvrp
# constraints:
#   capacity: { module: experiments.alg1_cvrp.feasibility, class: CapacityConstraint }
# operators:
#   relocate: { module: experiments.alg1_cvrp.operators, fn: relocate }
# templates:
#   ga_minimal: { module: experiments.alg1_cvrp.ga_template, fn: build_template }

def _load_manifest(path: str):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def _safe_get(modpath: str, attr: str):
    mod = importlib.import_module(modpath)
    return getattr(mod, attr)

def load_plugin_manifests(manifest_paths):
    """Read manifests and register constraints/operators/templates by name.
    `manifest_paths` may be filesystem paths ('.yaml') or dotted package paths that end with '/manifest.yaml'."""
    for p in manifest_paths or []:
        path = p
        if not os.path.exists(path) and p.endswith("/manifest.yaml"):
            pkg = p.replace("/manifest.yaml", "")
            try:
                mod = importlib.import_module(pkg)
                base = os.path.dirname(mod.__file__)
                path = os.path.join(base, "manifest.yaml")
            except Exception:
                continue
        if not os.path.exists(path):
            continue
        m = _load_manifest(path) or {}
        for name, spec in (m.get("constraints", {}) or {}).items():
            cls = _safe_get(spec["module"], spec["class"])
            register_constraint(name)(cls)
        for name, spec in (m.get("operators", {}) or {}).items():
            fn = _safe_get(spec["module"], spec["fn"])
            register_operator(name)(fn)
        for name, spec in (m.get("templates", {}) or {}).items():
            fn = _safe_get(spec["module"], spec["fn"])
            register_template(name)(fn)
