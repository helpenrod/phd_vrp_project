
import random
from typing import Callable, List
from .constraints import InstanceData, Solution, CompositeConstraint
from .objectives import total_travel_time
from .registry import register_template

@register_template("ils_first_improve")
def ils_first_improve_builder(operators: List[Callable]):
    """Returns a solver(inst, init, checker, rng_seed) implementing first-improvement local search.
    Operators propose feasible neighbors; acceptance is by improving objective."""
    def solve(inst: InstanceData, init: Solution, checker: CompositeConstraint, rng_seed: int = 0):
        random.seed(rng_seed)
        cur = init
        cur_cost = total_travel_time(cur, inst)
        improved = True
        while improved:
            improved = False
            random.shuffle(operators)
            for op in operators:
                nxt = op(cur, checker)
                if nxt is None:
                    continue
                nxt_cost = total_travel_time(nxt, inst)
                if nxt_cost + 1e-9 < cur_cost:
                    cur, cur_cost = nxt, nxt_cost
                    improved = True
                    break  # first improvement
        return cur, cur_cost
    return solve
