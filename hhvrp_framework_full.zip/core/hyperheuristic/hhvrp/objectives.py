
from .constraints import InstanceData, Solution

# Simple travel-time objective; replace with distance/cost as needed
def total_travel_time(sol: Solution, inst: InstanceData) -> float:
    cost = 0.0
    for r in sol:
        prev = 0
        for c in r:
            cost += inst.travel[prev][c]
            prev = c
        cost += inst.travel[prev][0]
    return cost
