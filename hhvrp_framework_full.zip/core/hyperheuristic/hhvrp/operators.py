
from typing import List, Optional
from .registry import register_operator
from .constraints import CompositeConstraint, Route, Solution

# Helper to test a route after a local edit
def _ok(new_route: Route, checker: CompositeConstraint) -> bool:
    return checker.route_feasible(new_route)

@register_operator("relocate")
def op_relocate(sol: Solution, checker: CompositeConstraint) -> Optional[Solution]:
    """Move one node between routes (or within a route). First feasible move wins."""
    for i, ri in enumerate(sol):
        for p in range(len(ri)):
            node = ri[p]
            for j, rj in enumerate(sol):
                for q in range(len(rj) + 1):
                    if i == j and (q == p or q == p + 1):
                        continue
                    new_ri = ri[:p] + ri[p+1:]
                    new_rj = rj[:q] + [node] + rj[q:]
                    if _ok(new_ri, checker) and _ok(new_rj, checker):
                        new = sol.copy()
                        new[i] = new_ri
                        new[j] = new_rj
                        return new
    return None

@register_operator("swap")
def op_swap(sol: Solution, checker: CompositeConstraint) -> Optional[Solution]:
    """Swap one node between two routes (or positions within the same route)."""
    for i, ri in enumerate(sol):
        for j, rj in enumerate(sol[i:], start=i):
            for p in range(len(ri)):
                for q in range(len(rj)):
                    if i == j and p == q:
                        continue
                    new_ri = ri.copy()
                    new_rj = rj.copy()
                    new_ri[p], new_rj[q] = new_rj[q], new_ri[p]
                    if _ok(new_ri, checker) and _ok(new_rj, checker):
                        new = sol.copy()
                        new[i] = new_ri
                        new[j] = new_rj
                        return new
    return None

@register_operator("two_opt_intra")
def op_two_opt_intra(sol: Solution, checker: CompositeConstraint) -> Optional[Solution]:
    """2-opt within a single route (first improvement)."""
    for i, r in enumerate(sol):
        n = len(r)
        for a in range(n - 1):
            for b in range(a + 1, n):
                new_r = r[:a] + list(reversed(r[a:b+1])) + r[b+1:]
                if _ok(new_r, checker):
                    new = sol.copy()
                    new[i] = new_r
                    return new
    return None

@register_operator("insert_best_feasible_tw")
def insert_best_feasible_tw(sol: Solution, checker: CompositeConstraint) -> Optional[Solution]:
    """TW-aware insertion: for each node, try all insertion positions and take the first feasible.
    (Cost is handled by the high-level template; this just proposes a feasible neighbor.)"""
    for i, ri in enumerate(sol):
        for p in range(len(ri)):
            node = ri[p]
            # try reinserting into any route (including same) at any position
            for j, rj in enumerate(sol):
                for q in range(len(rj) + 1):
                    if i == j and (q == p or q == p + 1):
                        continue
                    # remove and insert
                    new_ri = ri[:p] + ri[p+1:]
                    new_rj = rj[:q] + [node] + rj[q:]
                    if _ok(new_ri, checker) and _ok(new_rj, checker):
                        new = sol.copy()
                        new[i] = new_ri
                        new[j] = new_rj
                        return new
    return None
