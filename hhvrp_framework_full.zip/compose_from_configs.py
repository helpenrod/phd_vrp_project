
# Runner: compose a solver by reading existing experiment config.yaml files
import yaml
from core.hyperheuristic.hhvrp.builder import build_from_yaml
from core.hyperheuristic.hhvrp.config_bridge import auto_wire_from_configs

if __name__ == "__main__":
    spec = auto_wire_from_configs([
        ("alg1_cvrp", "experiments/alg1_cvrp/config.yaml"),
        ("alg2_vrptw", "experiments/alg2_vrptw/config.yaml"),
    ])
    yaml_text = yaml.safe_dump(spec)
    inst, checker, solve, _ = build_from_yaml(yaml_text)
    customers = list(range(1, len(inst.demand)))
    init = [customers]
    sol, cost = solve(inst, init, checker, rng_seed=spec.get("seed", 0))
    print("cost=", cost)
    print("solution=", sol)
